import start
import waitingPractice
import practice
import partBInstructions
import waitingPartB
import waitingPartC
import results
import survey
import partCInstructions

__all__ = ["start", "waitingPractice", "practice", "partBInstructions", "waitingPartB", "waitingPartC", "results", "survey"]
